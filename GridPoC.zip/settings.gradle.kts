rootProject.name = "GridPoC"

